class RelativeWeather {

  constructor(latitude, longitude) {

    this.latitude = latitude

    this.longitude = longitude

    this.apiKey = window.wxk
  }
}